//
//  ViewController.swift
//  eurekaPractice
//
//  Created by Hamza Mustafa on 26/10/2020.
//

import UIKit
import Eureka

class ViewController: FormViewController {
    
    typealias Emoji = String
    let 👦🏼 = "👦🏼", 🍐 = "🍐", 💁🏻 = "💁🏻", 🐗 = "🐗", 🐼 = "🐼", 🐻 = "🐻", 🐖 = "🐖", 🐡 = "🐡"

    override func viewDidLoad() {
        super.viewDidLoad()
        // Enables the navigation accessory and stops navigation when a disabled row is encountered
        navigationOptions = RowNavigationOptions.Enabled.union(.StopDisabledRow)
        // Enables smooth scrolling on navigation to off-screen rows
        animateScroll = true
        // Leaves 20pt of space between the keyboard and the highlighted row after scrolling to an off screen row
        rowKeyboardSpacing = 20
        
        loadForm()
    }
    
    
    func loadForm(){
        form
        +++ Section("Basic Info")
            <<< TextRow() { row in
                row.title = "First Name"
                row.placeholder = "First Name"
            }
            <<< TextRow() { row in
                row.title = "Last Name"
                row.placeholder = "Last Name"
            }
        
            <<< PasswordRow() { row in
                row.title = "Password"
                row.placeholder = "***"
            }
        
        +++ Section("Personal Info")
            <<< IntRow() { row in
                row.title = "Age"
                row.placeholder = "Age"
            }
            
            <<< DateRow() { row in
                row.value = Date()
                row.title = "Date Of Birth"
            }
            
            <<< LabelRow () {
                $0.title = "LabelRow"
                $0.value = "tap the row"
                }
                .onCellSelection { cell, row in
                    row.title = (row.title ?? "") + " 🇺🇾 "
                    row.reload() // or row.updateCell()
            }
        
            <<< CountDownInlineRow() {
                $0.value = Date();
                $0.title = "CountDownInlineRow"
            }
        
            <<< CheckRow() {
                $0.title = "CheckRow"
                $0.value = true
            }

            <<< SwitchRow() {
                $0.title = "SwitchRow"
                $0.value = true
            }

            <<< SliderRow() {
                $0.title = "SliderRow"
                $0.value = 5.0
            }
            .cellSetup { cell, row in
                cell.imageView?.image = #imageLiteral(resourceName: "selectedCircle")
            }
        
            <<< StepperRow() {
                $0.title = "StepperRow"
                $0.value = 1.0
              }.cellSetup({ (cell, row) in
                cell.imageView?.image = #imageLiteral(resourceName: "selectedRectangle")
              })
        
            +++ Section("SegmentedRow examples")

            <<< SegmentedRow<String>() {
                $0.options = ["One", "Two", "Three"]
            }

            <<< SegmentedRow<Emoji>(){
                $0.title = "Who are you?"
                $0.options = [💁🏻, 🍐, 👦🏼, 🐗, 🐼, 🐻 ]
                $0.value = 🍐
            }

            <<< SegmentedRow<String>(){
                $0.title = "SegmentedRow"
                $0.options = ["One", "Two", "Three", "Four"]
                $0.value = "Three"
                }.cellSetup { cell, row in
                    cell.imageView?.image = UIImage(named: "plus_image")
                }.onCellSelection({ (cell, row) in
                    cell.imageView?.image = UIImage(named: "selectedCircle")
                })
        
        +++ Section("Selector Rows Example")
        
            <<< ActionSheetRow<String>(){
                $0.title = "Action Sheet Row"
                $0.selectorTitle = "Your Favourite player?"
                $0.options = ["Virat Kohli","Babar Azam","Brain Lara"]
                $0.value = "choose"
            }
        
            <<< AlertRow<Emoji>() {
                $0.title = "Alert Row"
                $0.cancelTitle = "Dismiss"
                $0.selectorTitle = "Choose Fruit"
                $0.options = [💁🏻, 🍐, 👦🏼, 🐗, 🐼, 🐻 ]
                $0.value = 🍐
            }.onChange({ (row) in
                print(row.value ?? "No Value")
            })
            .onPresent{ _, to in
                to.view.tintColor = .green
            }
        
            <<< PushRow<Emoji>() {
                $0.title = "Push Row"
                $0.options = [💁🏻, 🍐, 👦🏼, 🐗, 🐼, 🐻 ]
                $0.value = 💁🏻
                $0.selectorTitle = "Choose an Emoji"
            }.onPresent{ from, to in
                to.dismissOnSelection = false
                to.dismissOnChange = false
            }
        
        
            <<< PushRow<Emoji>() {
                $0.title = "Push Row"
                $0.options = [💁🏻, 🍐, 👦🏼, 🐗, 🐼, 🐻 ]
                $0.value = 💁🏻
                $0.selectorTitle = "Choose an Emoji"
            }.onPresent{ from, to in
                to.dismissOnSelection = false
                to.dismissOnChange = false
                to.sectionKeyForValue = { [self] option in
                    switch option {
                        case self.💁🏻,self.👦🏼: return "People"
                        case self.🐗,self.🐼,self.🐻: return "Animals"
                        case self.🍐: return "Food"
                        default: return ""
                    }
                }
            }
        
        
        
        
        
            
        
        
        
        

    }
}
